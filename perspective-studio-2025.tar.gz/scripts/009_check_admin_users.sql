-- Check current admin users in the table
SELECT * FROM admin_users;

-- Check if there are any users at all
SELECT COUNT(*) as total_admin_users FROM admin_users;
